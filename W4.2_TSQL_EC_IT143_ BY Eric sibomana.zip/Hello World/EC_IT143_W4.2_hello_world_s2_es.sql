-- Step 2: State the current answer path and next step.
-- A: Ask SQL Server to return a greeting and the current server date/time.
-- Next: query the imported source table, then preserve the result in a view.

