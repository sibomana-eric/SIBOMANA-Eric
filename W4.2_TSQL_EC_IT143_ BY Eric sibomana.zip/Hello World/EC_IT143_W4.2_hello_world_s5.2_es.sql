/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
*/
USE EC_IT143_DA;
GO
-- Step 5.2: Refined destination table with a primary key, explicit data types, and a default.
IF OBJECT_ID(N'dbo.t_hello_world', N'U') IS NOT NULL DROP TABLE dbo.t_hello_world;
CREATE TABLE dbo.t_hello_world (
    [hello_world_id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [my_message] VARCHAR(50) NOT NULL,
    [current_date_time] DATETIME NOT NULL CONSTRAINT DF_t_hello_world_current_date_time DEFAULT (GETDATE())
);
GO

