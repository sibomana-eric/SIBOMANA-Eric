/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
 Purpose: What is the current date and time?
 Assumptions: source table and column names match the supplied dataset imports.
*/
USE EC_IT143_DA;
GO
-- Step 4: Save the reusable query as a view.
GO
CREATE OR ALTER VIEW dbo.hello_world_load
AS
SELECT 'Hello World' AS my_message, GETDATE() AS current_date_time;
GO

