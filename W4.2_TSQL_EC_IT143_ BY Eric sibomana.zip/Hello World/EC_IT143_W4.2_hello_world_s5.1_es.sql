/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
 Purpose: What is the current date and time?
 Assumptions: source table and column names match the supplied dataset imports.
*/
USE EC_IT143_DA;
GO
-- Step 5.1: Initial table generated from the view. Re-run only after dropping destination.
IF OBJECT_ID(N'dbo.t_hello_world', N'U') IS NOT NULL DROP TABLE dbo.t_hello_world;
SELECT * INTO dbo.t_hello_world FROM dbo.hello_world_load;
GO

