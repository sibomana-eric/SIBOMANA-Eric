/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
 Purpose: What is the current date and time?
 Assumptions: source table and column names match the supplied dataset imports.
*/
USE EC_IT143_DA;
GO
-- Step 8: Execute the stored procedure to refresh the destination table.
EXEC dbo.usp_hello_world_load;
GO
SELECT * FROM dbo.t_hello_world;

