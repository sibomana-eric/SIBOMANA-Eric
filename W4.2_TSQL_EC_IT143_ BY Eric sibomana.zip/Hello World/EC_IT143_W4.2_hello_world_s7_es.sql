/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
*/
USE EC_IT143_DA;
GO
-- Step 7: Encapsulate the refresh operation in a stored procedure.
CREATE OR ALTER PROCEDURE dbo.usp_hello_world_load
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE dbo.t_hello_world;
    INSERT INTO dbo.t_hello_world ([my_message], [current_date_time])
    SELECT [my_message], [current_date_time]
    FROM dbo.hello_world_load;
END;
GO

