-- Step 1: Start with one concise question.
-- Q: What is the current date and time?

