/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
 Purpose: How many mathematics students received each final grade?
 Assumptions: source table and column names match the supplied dataset imports.
*/
USE EC_IT143_DA;
GO
-- Step 5.2: Refined destination table with a key and explicit data types.
IF OBJECT_ID(N'dbo.t_student_math_grade_counts', N'U') IS NOT NULL DROP TABLE dbo.t_student_math_grade_counts;
CREATE TABLE dbo.t_student_math_grade_counts (
    [final_grade] TINYINT NOT NULL PRIMARY KEY,
    [student_count] BIGINT NOT NULL
);
GO

