-- Step 2: State the current answer path and next step.
-- A: Count student records by G3 final grade from the mathematics dataset.
-- Next: query the imported source table, then preserve the result in a view.

