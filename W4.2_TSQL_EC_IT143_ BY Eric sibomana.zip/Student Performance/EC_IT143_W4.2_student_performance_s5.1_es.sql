/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
 Purpose: How many mathematics students received each final grade?
 Assumptions: source table and column names match the supplied dataset imports.
*/
USE EC_IT143_DA;
GO
-- Step 5.1: Initial table generated from the view. Re-run only after dropping destination.
IF OBJECT_ID(N'dbo.student_math_grade_counts_load', N'V') IS NULL
BEGIN
    PRINT N'View dbo.student_math_grade_counts_load is missing. Import the mathematics student source table containing G3 (import student-mat.csv with semicolon delimiter and header row), then run step 4.';
    RETURN;
END;

IF OBJECT_ID(N'dbo.t_student_math_grade_counts', N'U') IS NOT NULL DROP TABLE dbo.t_student_math_grade_counts;
SELECT * INTO dbo.t_student_math_grade_counts FROM dbo.student_math_grade_counts_load;
GO


