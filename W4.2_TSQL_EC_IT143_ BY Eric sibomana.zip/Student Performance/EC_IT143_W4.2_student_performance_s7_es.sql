/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
*/
USE EC_IT143_DA;
GO
-- Step 7: Encapsulate the refresh operation in a stored procedure.
CREATE OR ALTER PROCEDURE dbo.usp_student_math_grade_counts_load
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE dbo.t_student_math_grade_counts;
    INSERT INTO dbo.t_student_math_grade_counts ([final_grade], [student_count])
    SELECT [final_grade], [student_count]
    FROM dbo.student_math_grade_counts_load;
END;
GO

