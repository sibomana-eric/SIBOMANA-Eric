/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
*/
USE EC_IT143_DA;
GO
-- Step 6: Refresh the materialized result from its view.
IF OBJECT_ID(N'dbo.student_math_grade_counts_load', N'V') IS NULL OR OBJECT_ID(N'dbo.t_student_math_grade_counts', N'U') IS NULL
BEGIN
    PRINT N'Run steps 4 and 5.2 after importing the mathematics student source table containing G3 (import student-mat.csv with semicolon delimiter and header row), then rerun step 6.';
    RETURN;
END;

TRUNCATE TABLE dbo.t_student_math_grade_counts;
INSERT INTO dbo.t_student_math_grade_counts ([final_grade], [student_count])
SELECT [final_grade], [student_count]
FROM dbo.student_math_grade_counts_load;
GO


