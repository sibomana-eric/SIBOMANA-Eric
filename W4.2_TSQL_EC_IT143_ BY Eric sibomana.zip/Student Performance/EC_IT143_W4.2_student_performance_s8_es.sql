/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
 Purpose: How many mathematics students received each final grade?
 Assumptions: source table and column names match the supplied dataset imports.
*/
USE EC_IT143_DA;
GO
-- Step 8: Execute the stored procedure to refresh the destination table.
IF OBJECT_ID(N'dbo.student_math_grade_counts_load', N'V') IS NULL OR OBJECT_ID(N'dbo.t_student_math_grade_counts', N'U') IS NULL
BEGIN
    PRINT N'Run steps 4, 5.2, 6, and 7 after importing the mathematics student source table containing G3 (import student-mat.csv with semicolon delimiter and header row), then rerun step 8.';
    RETURN;
END;

EXEC dbo.usp_student_math_grade_counts_load;
GO
SELECT * FROM dbo.t_student_math_grade_counts;


