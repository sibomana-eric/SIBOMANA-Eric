-- Step 1: Start with one concise question.
-- Q: How many mathematics students received each final grade?

