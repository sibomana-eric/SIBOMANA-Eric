/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
*/
USE [EC_IT143_DA];
GO
-- Step 4: Create the reusable view over the imported mathematics-student table.
DECLARE @source_schema sysname, @source_table sysname;
SELECT TOP (1) @source_schema = s.name, @source_table = t.name
FROM sys.tables AS t
JOIN sys.schemas AS s ON s.schema_id = t.schema_id
JOIN sys.columns AS c ON c.object_id = t.object_id AND c.name = N'G3'
WHERE t.is_ms_shipped = 0
ORDER BY CASE WHEN LOWER(t.name) LIKE N'%mat%' THEN 0 ELSE 1 END, t.name;
IF @source_table IS NULL
BEGIN
    PRINT N'Student table with G3 not found. Import student-mat.csv into EC_IT143_DA using a semicolon delimiter and header row.';
    RETURN;
END;
DECLARE @ddl nvarchar(max) = N'CREATE OR ALTER VIEW dbo.student_math_grade_counts_load AS SELECT [G3] AS [final_grade], COUNT_BIG(*) AS [student_count] FROM ' + QUOTENAME(@source_schema) + N'.' + QUOTENAME(@source_table) + N' GROUP BY [G3];';
EXEC sys.sp_executesql @ddl;
PRINT N'Created dbo.student_math_grade_counts_load from ' + QUOTENAME(@source_schema) + N'.' + QUOTENAME(@source_table);
GO

