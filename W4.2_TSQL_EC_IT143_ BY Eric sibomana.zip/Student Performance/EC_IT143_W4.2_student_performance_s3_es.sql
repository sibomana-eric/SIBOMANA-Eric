/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
*/
USE [EC_IT143_DA];
GO
-- Step 3: Find the imported mathematics-student table by its G3 column.
DECLARE @source_schema sysname, @source_table sysname;
SELECT TOP (1) @source_schema = s.name, @source_table = t.name
FROM sys.tables AS t
JOIN sys.schemas AS s ON s.schema_id = t.schema_id
JOIN sys.columns AS c ON c.object_id = t.object_id AND c.name = N'G3'
WHERE t.is_ms_shipped = 0
ORDER BY CASE WHEN LOWER(t.name) LIKE N'%mat%' THEN 0 ELSE 1 END, t.name;
IF @source_table IS NULL
BEGIN
    PRINT N'Student table with G3 not found. Import student-mat.csv into EC_IT143_DA using a semicolon delimiter and header row.';
    RETURN;
END;
DECLARE @sql nvarchar(max) = N'SELECT [G3] AS [final_grade], COUNT_BIG(*) AS [student_count] FROM ' + QUOTENAME(@source_schema) + N'.' + QUOTENAME(@source_table) + N' GROUP BY [G3] ORDER BY [G3];';
PRINT N'Using source table ' + QUOTENAME(@source_schema) + N'.' + QUOTENAME(@source_table);
EXEC sys.sp_executesql @sql;
GO

