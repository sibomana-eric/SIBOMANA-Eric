/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
 Purpose: What is the total number of bike rides for each month number across all years?
 Assumptions: source table and column names match the supplied dataset imports.
*/
USE EC_IT143_DA;
GO
-- Step 5.1: Initial table generated from the view. Re-run only after dropping destination.
IF OBJECT_ID(N'dbo.bike_monthly_rides_load', N'V') IS NULL
BEGIN
    PRINT N'View dbo.bike_monthly_rides_load is missing. Import a bike source table containing mnth and cnt (import day.csv with header row), then run step 4.';
    RETURN;
END;

IF OBJECT_ID(N'dbo.t_bike_monthly_rides', N'U') IS NOT NULL DROP TABLE dbo.t_bike_monthly_rides;
SELECT * INTO dbo.t_bike_monthly_rides FROM dbo.bike_monthly_rides_load;
GO



