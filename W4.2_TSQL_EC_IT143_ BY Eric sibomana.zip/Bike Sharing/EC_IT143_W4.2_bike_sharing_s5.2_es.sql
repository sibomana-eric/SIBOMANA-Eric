/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
 Purpose: What is the total number of bike rides for each month number across all years?
 Assumptions: source table and column names match the supplied dataset imports.
*/
USE EC_IT143_DA;
GO
-- Step 5.2: Refined destination table with a key and explicit data types.
IF OBJECT_ID(N'dbo.t_bike_monthly_rides', N'U') IS NOT NULL DROP TABLE dbo.t_bike_monthly_rides;
CREATE TABLE dbo.t_bike_monthly_rides (
    [month_number] TINYINT NOT NULL PRIMARY KEY,
    [total_rides] INT NOT NULL
);
GO


