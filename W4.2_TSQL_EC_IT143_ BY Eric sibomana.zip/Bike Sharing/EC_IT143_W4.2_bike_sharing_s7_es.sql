/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
*/
USE EC_IT143_DA;
GO
-- Step 7: Encapsulate the refresh operation in a stored procedure.
CREATE OR ALTER PROCEDURE dbo.usp_bike_monthly_rides_load
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE dbo.t_bike_monthly_rides;
    INSERT INTO dbo.t_bike_monthly_rides ([month_number], [total_rides])
    SELECT [month_number], [total_rides]
    FROM dbo.bike_monthly_rides_load;
END;
GO


