/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
*/
USE EC_IT143_DA;
GO
-- Step 6: Refresh the materialized result from its view.
IF OBJECT_ID(N'dbo.bike_monthly_rides_load', N'V') IS NULL OR OBJECT_ID(N'dbo.t_bike_monthly_rides', N'U') IS NULL
BEGIN
    PRINT N'Run steps 4 and 5.2 after importing a bike source table containing mnth and cnt (import day.csv with header row), then rerun step 6.';
    RETURN;
END;

TRUNCATE TABLE dbo.t_bike_monthly_rides;
INSERT INTO dbo.t_bike_monthly_rides ([month_number], [total_rides])
SELECT [month_number], [total_rides]
FROM dbo.bike_monthly_rides_load;
GO



