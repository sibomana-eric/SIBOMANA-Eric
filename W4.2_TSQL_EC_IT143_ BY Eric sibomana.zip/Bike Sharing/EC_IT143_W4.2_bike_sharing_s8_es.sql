/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
 Purpose: What is the total number of bike rides for each month number across all years?
 Assumptions: source table and column names match the supplied dataset imports.
*/
USE EC_IT143_DA;
GO
-- Step 8: Execute the stored procedure to refresh the destination table.
IF OBJECT_ID(N'dbo.bike_monthly_rides_load', N'V') IS NULL OR OBJECT_ID(N'dbo.t_bike_monthly_rides', N'U') IS NULL
BEGIN
    PRINT N'Run steps 4, 5.2, 6, and 7 after importing a bike source table containing mnth and cnt (import day.csv with header row), then rerun step 8.';
    RETURN;
END;

EXEC dbo.usp_bike_monthly_rides_load;
GO
SELECT * FROM dbo.t_bike_monthly_rides;



