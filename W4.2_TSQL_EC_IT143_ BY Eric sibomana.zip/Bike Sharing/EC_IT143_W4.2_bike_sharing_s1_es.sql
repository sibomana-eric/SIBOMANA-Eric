-- Step 1: Start with one concise question.
-- Q: What is the total number of bike rides for each month number across all years?


