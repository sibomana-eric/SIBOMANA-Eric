/*
 Author: Eric Sibomana (ES)
 Course: EC_IT143
 Assignment: W4.2 Answer-Focused T-SQL Data Manipulation
*/
USE [EC_IT143_DA];
GO
-- Step 4: Create the reusable view over the imported bike table.
DECLARE @source_schema sysname, @source_table sysname;
SELECT TOP (1) @source_schema = s.name, @source_table = t.name
FROM sys.tables AS t
JOIN sys.schemas AS s ON s.schema_id = t.schema_id
JOIN sys.columns AS c1 ON c1.object_id = t.object_id AND c1.name = N'mnth'
JOIN sys.columns AS c2 ON c2.object_id = t.object_id AND c2.name = N'cnt'
WHERE t.is_ms_shipped = 0
ORDER BY CASE WHEN LOWER(t.name) = N'day' THEN 0 ELSE 1 END, t.name;
IF @source_table IS NULL
BEGIN
    PRINT N'Bike data table not found. Import day.csv into EC_IT143_DA with its header row, then rerun.';
    RETURN;
END;
DECLARE @ddl nvarchar(max) = N'CREATE OR ALTER VIEW dbo.bike_monthly_rides_load AS SELECT [mnth] AS [month_number], SUM([cnt]) AS [total_rides] FROM ' + QUOTENAME(@source_schema) + N'.' + QUOTENAME(@source_table) + N' GROUP BY [mnth];';
EXEC sys.sp_executesql @ddl;
PRINT N'Created dbo.bike_monthly_rides_load from ' + QUOTENAME(@source_schema) + N'.' + QUOTENAME(@source_table);
GO

