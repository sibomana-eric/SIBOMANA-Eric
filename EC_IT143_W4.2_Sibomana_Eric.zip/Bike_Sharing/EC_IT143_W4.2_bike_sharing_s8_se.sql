USE EC_IT143_DA;
GO

EXEC dbo.usp_bike_sharing_load;
GO
