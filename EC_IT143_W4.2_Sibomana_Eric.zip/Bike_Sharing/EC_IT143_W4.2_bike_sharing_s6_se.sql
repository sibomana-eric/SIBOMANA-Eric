USE EC_IT143_DA;
GO

-- 1) Reload data
TRUNCATE TABLE dbo.t_bike_sharing;

INSERT INTO dbo.t_bike_sharing
(
    dteday,
    total_bike_rentals
)
SELECT
    v.dteday,
    v.total_bike_rentals
FROM dbo.v_bike_sharing_load AS v;

-- 2) Review results
SELECT
    t.*
FROM dbo.t_bike_sharing AS t
ORDER BY t.dteday;
GO
