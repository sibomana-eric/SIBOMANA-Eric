USE EC_IT143_DA;
GO

-- Q: How many bikes were rented each day?
SELECT
    d.dteday,
    d.cnt AS total_bike_rentals
FROM dbo.bike_day AS d
ORDER BY d.dteday;
GO
