USE EC_IT143_DA;
GO

DROP TABLE IF EXISTS dbo.t_bike_sharing;
GO

SELECT
    v.dteday,
    v.total_bike_rentals
INTO dbo.t_bike_sharing
FROM dbo.v_bike_sharing_load AS v;
GO
