USE EC_IT143_DA;
GO

DROP VIEW IF EXISTS dbo.v_bike_sharing_load;
GO

CREATE VIEW dbo.v_bike_sharing_load
AS
/*
NAME: dbo.v_bike_sharing_load
PURPOSE: Create the Bike Sharing - Load view
*/
SELECT
    d.dteday,
    d.cnt AS total_bike_rentals
FROM dbo.bike_day AS d;
GO
