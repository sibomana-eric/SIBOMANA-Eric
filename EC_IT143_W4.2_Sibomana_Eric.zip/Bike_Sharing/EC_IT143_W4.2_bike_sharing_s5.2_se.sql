USE EC_IT143_DA;
GO

DROP TABLE IF EXISTS dbo.t_bike_sharing;
GO

CREATE TABLE dbo.t_bike_sharing
(
    dteday DATE NOT NULL,
    total_bike_rentals INT NOT NULL,
    CONSTRAINT PK_t_bike_sharing
        PRIMARY KEY CLUSTERED (dteday ASC)
);
GO
