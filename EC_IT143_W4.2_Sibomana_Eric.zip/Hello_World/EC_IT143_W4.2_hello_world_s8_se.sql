USE EC_IT143_DA;
GO

EXEC dbo.usp_hello_world_load;
GO
