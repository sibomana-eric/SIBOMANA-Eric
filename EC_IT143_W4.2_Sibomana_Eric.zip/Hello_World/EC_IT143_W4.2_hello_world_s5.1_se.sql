USE EC_IT143_DA;
GO

DROP TABLE IF EXISTS dbo.t_hello_world;
GO

SELECT
    v.my_message,
    v.current_date_time
INTO dbo.t_hello_world
FROM dbo.v_hello_world_load AS v;
GO
