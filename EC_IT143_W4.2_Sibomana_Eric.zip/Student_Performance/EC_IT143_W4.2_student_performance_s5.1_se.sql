USE EC_IT143_DA;
GO

DROP TABLE IF EXISTS dbo.t_student_performance;
GO

SELECT
    v.school,
    v.average_final_grade
INTO dbo.t_student_performance
FROM dbo.v_student_performance_load AS v;
GO
