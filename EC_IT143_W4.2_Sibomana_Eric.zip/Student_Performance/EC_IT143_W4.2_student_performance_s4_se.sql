USE EC_IT143_DA;
GO

DROP VIEW IF EXISTS dbo.v_student_performance_load;
GO

CREATE VIEW dbo.v_student_performance_load
AS
/*
NAME: dbo.v_student_performance_load
PURPOSE: Create the Student Performance - Load view
*/
SELECT
    s.school,
    AVG(CAST(s.G3 AS DECIMAL(10,2))) AS average_final_grade
FROM dbo.student_performance AS s
GROUP BY s.school;
GO
