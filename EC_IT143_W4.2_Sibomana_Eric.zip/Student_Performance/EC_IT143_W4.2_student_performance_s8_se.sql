USE EC_IT143_DA;
GO

EXEC dbo.usp_student_performance_load;
GO
