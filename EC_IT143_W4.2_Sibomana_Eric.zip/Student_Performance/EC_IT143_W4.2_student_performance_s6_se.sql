USE EC_IT143_DA;
GO

-- 1) Reload data
TRUNCATE TABLE dbo.t_student_performance;

INSERT INTO dbo.t_student_performance
(
    school,
    average_final_grade
)
SELECT
    v.school,
    v.average_final_grade
FROM dbo.v_student_performance_load AS v;

-- 2) Review results
SELECT
    t.*
FROM dbo.t_student_performance AS t
ORDER BY t.school;
GO
