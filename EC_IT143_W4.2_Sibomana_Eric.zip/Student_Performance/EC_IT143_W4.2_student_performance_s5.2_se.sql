USE EC_IT143_DA;
GO

DROP TABLE IF EXISTS dbo.t_student_performance;
GO

CREATE TABLE dbo.t_student_performance
(
    school VARCHAR(10) NOT NULL,
    average_final_grade DECIMAL(10,2) NOT NULL,
    CONSTRAINT PK_t_student_performance
        PRIMARY KEY CLUSTERED (school ASC)
);
GO
