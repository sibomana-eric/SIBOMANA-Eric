USE EC_IT143_DA;
GO

-- Q: What is the average final grade by school?
SELECT
    s.school,
    AVG(CAST(s.G3 AS DECIMAL(10,2))) AS average_final_grade
FROM dbo.student_performance AS s
GROUP BY s.school
ORDER BY s.school;
GO
